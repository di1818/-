<?php
/* ============================================================
   Отправка письма о заявке. Подключается из send.php и diag.php.
   Снаружи закрыт в .htaccess.

   ОСНОВНОЙ СПОСОБ — mail() хостинга, от robot@bannikov-hr.ru.
   Так работал старый сайт, и письма стабильно приходили во «Входящие»
   Яндекс Почты. Пароль от почты для этого не нужен.

   ЗАПАСНОЙ, НЕОБЯЗАТЕЛЬНЫЙ — SMTP Яндекса. Включается, только если
   в bannikov-config.php вписаны smtp_user и smtp_pass (пароль
   приложения). Понадобится, если письма когда-нибудь начнут
   попадать в спам. Пока ключей нет — этот код не используется.
   ============================================================ */

if (!function_exists('bh_mail')) {

    function bh_mime($s) {
        return '=?UTF-8?B?' . base64_encode($s) . '?=';
    }

    /* Письмо целиком: заголовки + текст в base64. base64 заодно
       снимает проблему строк, начинающихся с точки, в SMTP. */
    function bh_message($from, $to, $subject, $text, $replyTo) {
        $h = [];
        $h[] = 'From: ' . bh_mime('Сайт bannikov-hr.ru') . ' <' . $from . '>';
        $h[] = 'To: <' . $to . '>';
        if ($replyTo !== '') $h[] = 'Reply-To: <' . $replyTo . '>';
        $h[] = 'Subject: ' . bh_mime($subject);
        $h[] = 'Date: ' . date('r');
        $h[] = 'Message-ID: <' . time() . '.' . bin2hex(random_bytes(6)) . '@bannikov-hr.ru>';
        $h[] = 'MIME-Version: 1.0';
        $h[] = 'Content-Type: text/plain; charset=utf-8';
        $h[] = 'Content-Transfer-Encoding: base64';
        return implode("\r\n", $h) . "\r\n\r\n" . rtrim(chunk_split(base64_encode($text), 76, "\r\n"));
    }

    /* Разговор с SMTP-сервером. $onlyAuth = true — только проверить
       вход, ничего не отправляя (для страницы диагностики). */
    function bh_smtp($cfg, $to, $subject, $text, $replyTo, &$why, $onlyAuth = false) {
        $user = trim((string) ($cfg['smtp_user'] ?? ''));
        $pass = (string) ($cfg['smtp_pass'] ?? '');
        $host = trim((string) ($cfg['smtp_host'] ?? 'smtp.yandex.ru'));
        $port = (int) ($cfg['smtp_port'] ?? 465);

        $fp = @stream_socket_client('ssl://' . $host . ':' . $port, $errno, $errstr, 8);
        if (!$fp) {
            $why = 'нет соединения с ' . $host . ': ' . $errstr;
            return false;
        }
        stream_set_timeout($fp, 12);

        $read = function () use ($fp) {
            $data = '';
            while (($line = fgets($fp, 1024)) !== false) {
                $data .= $line;
                // многострочный ответ: «250-...», последняя строка — «250 ...»
                if (strlen($line) < 4 || $line[3] === ' ') break;
            }
            return $data;
        };
        $cmd = function ($line, $expect) use ($fp, $read, &$why) {
            if ($line !== null) fwrite($fp, $line . "\r\n");
            $r = $read();
            if (!in_array((int) substr($r, 0, 3), (array) $expect, true)) {
                $why = trim($r) === '' ? 'почтовый сервер не ответил (таймаут)' : 'почтовый сервер ответил: ' . trim($r);
                return false;
            }
            return true;
        };

        $ok = $cmd(null, 220)
            && $cmd('EHLO bannikov-hr.ru', 250)
            && $cmd('AUTH LOGIN', 334)
            && $cmd(base64_encode($user), 334)
            && $cmd(base64_encode($pass), 235);

        if ($ok && !$onlyAuth) {
            $ok = $cmd('MAIL FROM:<' . $user . '>', 250)
                && $cmd('RCPT TO:<' . $to . '>', [250, 251])
                && $cmd('DATA', 354)
                && $cmd(bh_message($user, $to, $subject, $text, $replyTo) . "\r\n.", 250);
        }

        @fwrite($fp, "QUIT\r\n");
        fclose($fp);
        return $ok;
    }

    /* mail() хостинга — заголовки те же, что у старого сайта (письма
       с них доходили во «Входящие»). Добавлена только тема: раньше она
       уходила без кодировки, и почта показывала «(Без темы)». */
    function bh_host_mail($to, $subject, $text, $replyTo) {
        if (!function_exists('mail')) return false;
        $headers = "From: robot@bannikov-hr.ru\r\n"
            . ($replyTo !== '' ? 'Reply-To: ' . $replyTo . "\r\n" : '')
            . "Content-Type: text/plain; charset=utf-8";
        return (bool) @mail($to, bh_mime($subject), $text, $headers);
    }

    function bh_mail($cfg, $to, $subject, $text, $replyTo, &$why) {
        $why = '';
        $hasSmtp = trim((string) ($cfg['smtp_user'] ?? '')) !== ''
            && (string) ($cfg['smtp_pass'] ?? '') !== ''
            && ($cfg['smtp_pass'] ?? '') !== 'ВПИСАТЬ';

        // SMTP — только если его специально включили в конфиге
        if ($hasSmtp) {
            if (bh_smtp($cfg, $to, $subject, $text, $replyTo, $why)) return true;
            $smtpWhy = $why;
            if (bh_host_mail($to, $subject, $text, $replyTo)) {
                $why = 'SMTP не сработал (' . $smtpWhy . '), письмо ушло обычным путём через хостинг';
                return false; // письмо ушло, но причину фиксируем в errors.log
            }
            $why = 'SMTP: ' . $smtpWhy . '; отправка через хостинг тоже не сработала';
            return false;
        }

        // Обычный путь — как на старом сайте
        if (bh_host_mail($to, $subject, $text, $replyTo)) return true;
        $why = 'хостинг не принял письмо (функция mail() не сработала)';
        return false;
    }
}
