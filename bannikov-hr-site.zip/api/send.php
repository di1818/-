<?php
/* ============================================================
   bannikov-hr.ru — единый приёмник заявок

   Принимает POST с JSON от форм на /audit/, /praktikum/ и /calculator/.
   Отправляет заявку письмом на Яндекс Почту и пишет в лог-файл.

   Почему почта, а не Telegram: хостинг в России с перебоями
   достаёт до api.telegram.org, и заявки туда регулярно не доходили.
   Письмо уходит обычной почтой хостинга (как на старом сайте),
   пароль от ящика не нужен. Подробности — в mailer.php.

   НАСТРОЙКИ ЗДЕСЬ НЕ ХРАНЯТСЯ.
   Адрес для заявок лежит в bannikov-config.php ВЫШЕ публичной папки:

     domains/bannikov-hr.ru/
       bannikov-config.php   ← сюда (наружу не отдаётся никогда)
       leads.log             ← сюда пишутся все заявки
       errors.log            ← сюда пишется, если письмо не ушло
       public_html/          ← это и есть сайт
         api/send.php

   Образец конфига — bannikov-config.sample.php.
   ============================================================ */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
date_default_timezone_set('Europe/Moscow');

function fail($msg = 'bad request', $code = 400) {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') fail('method not allowed', 405);

/* ---------- конфиг ---------- */

$CONFIG = null;
foreach ([__DIR__ . '/../../bannikov-config.php', __DIR__ . '/../bannikov-config.php'] as $path) {
    if (is_readable($path)) { $CONFIG = require $path; break; }
}
if (!is_array($CONFIG)) $CONFIG = [];

// Куда слать. 'email' — ключ из старого конфига, чтобы сайт не замолчал,
// если новый ключ ещё не вписан.
$MAIL_TO = trim((string) ($CONFIG['mail_to'] ?? $CONFIG['email'] ?? ''));
if (!filter_var($MAIL_TO, FILTER_VALIDATE_EMAIL)) $MAIL_TO = '';

$PRIVATE_DIR = $CONFIG['private_dir'] ?? dirname(__DIR__, 2);

/* ---------- тело запроса ---------- */

$raw = file_get_contents('php://input', false, null, 0, 20000);
$d = json_decode($raw, true);
if (!is_array($d)) fail('bad payload');

// ловушка для спам-ботов: скрытое поле должно остаться пустым
if (!empty($d['hp'])) { echo json_encode(['ok' => true]); exit; }

/* ---------- ограничение частоты ---------- */

$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$rateFile = $PRIVATE_DIR . '/rate-' . md5($ip) . '.tmp';
$now = time();
$hits = [];
if (is_readable($rateFile)) {
    $hits = array_filter(explode(',', (string) @file_get_contents($rateFile)), function ($t) use ($now) {
        return is_numeric($t) && $now - (int) $t < 600;
    });
}
if (count($hits) >= 5) fail('too many requests', 429);
$hits[] = $now;
@file_put_contents($rateFile, implode(',', $hits), LOCK_EX);

// изредка подчищаем счётчики старше часа, чтобы папка не обрастала файлами
if (mt_rand(1, 50) === 1) {
    foreach ((array) @glob($PRIVATE_DIR . '/rate-*.tmp') as $old) {
        if (@filemtime($old) < $now - 3600) @unlink($old);
    }
}

/* ---------- поля ---------- */

function field($d, $key, $len) {
    $v = trim((string) ($d[$key] ?? ''));
    // На битом UTF-8 preg_replace возвращает null — тогда оставляем как было,
    // иначе живая заявка молча превратилась бы в пустую строку и отвалилась.
    $clean = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', '', $v);
    return mb_substr($clean === null ? $v : $clean, 0, $len);
}

$projects = [
    'audit'      => 'HR-АУДИТ',
    'praktikum'  => 'ПРАКТИКУМ',
    'webinar'    => 'ВЕБИНАР (перезвонить)',
    'calculator' => 'КАЛЬКУЛЯТОР',
    'hub'        => 'ГЛАВНАЯ',
];
// значок в первой строке письма — как в письмах старого сайта
$icons = [
    'audit'      => '🔔',
    'praktikum'  => '🎓',
    'webinar'    => '📣',
    'calculator' => '🧮',
    'hub'        => '✉️',
];
$project = (string) ($d['project'] ?? 'hub');
if (!isset($projects[$project])) $project = 'hub';

$name    = field($d, 'name', 100);
$contact = field($d, 'contact', 150);
$role    = field($d, 'role', 80);
$size    = field($d, 'size', 30);
$pain    = field($d, 'pain', 160);
$comment = field($d, 'comment', 500);
$source  = field($d, 'source', 200);
$page    = field($d, 'page', 120);

// Рекламные метки. yclid и ClientID Метрики нужны, чтобы потом
// загрузить в Метрику офлайн-конверсию «заявка → оплаченная сделка»:
// без них Директ не узнает, какая заявка принесла деньги, и будет
// оптимизироваться на все подряд.
$yclid   = field($d, 'yclid', 100);
$ymUid   = field($d, 'ym_uid', 40);
$utm = [];
foreach (['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'] as $k) {
    $v = field($d, $k, 120);
    if ($v !== '') $utm[$k] = $v;
}

if ($name === '' || $contact === '') fail('empty required fields');
if (empty($d['agree'])) fail('consent required');

/* ---------- текст заявки ---------- */

$lines = [$icons[$project] . ' Заявка · ' . $projects[$project], ''];
$lines[] = 'Имя: ' . $name;
$lines[] = 'Контакт: ' . $contact;
if ($role    !== '') $lines[] = 'Роль: ' . $role;
if ($size    !== '') $lines[] = 'Сотрудников: ' . $size;
if ($pain    !== '') $lines[] = 'Запрос: ' . $pain;
if ($comment !== '') $lines[] = 'Комментарий: ' . $comment;
$lines[] = '';
$lines[] = 'Источник: ' . ($source !== '' ? $source : '—');
$lines[] = 'Страница: ' . ($page !== '' ? $page : '—');
if ($utm) {
    foreach ($utm as $k => $v) $lines[] = str_replace('utm_', 'UTM ', $k) . ': ' . $v;
}
if ($yclid !== '') $lines[] = 'yclid: ' . $yclid;
if ($ymUid !== '') $lines[] = 'ClientID: ' . $ymUid;
$lines[] = 'Время: ' . date('d.m.Y H:i') . ' (МСК)';

$text = implode("\n", $lines);

/* ---------- 1. страховочный лог — пишем ПЕРВЫМ ----------
   Что бы ни случилось с почтой дальше, заявка уже на диске. */

@file_put_contents($PRIVATE_DIR . '/leads.log', $text . "\n" . str_repeat('-', 40) . "\n", FILE_APPEND | LOCK_EX);

/* ---------- 2. письмо на Яндекс Почту ---------- */

require __DIR__ . '/mailer.php';

$why = '';
$sent = false;
if ($MAIL_TO === '') {
    $why = 'в bannikov-config.php не вписан адрес mail_to';
} else {
    $subject = 'Заявка · ' . $projects[$project] . ' — ' . $name;
    // Если человек оставил почту — «Ответить» в письме сразу пойдёт ему
    $replyTo = filter_var($contact, FILTER_VALIDATE_EMAIL) ? $contact : '';
    $sent = bh_mail($CONFIG, $MAIL_TO, $subject, $text, $replyTo, $why);
}

if (!$sent) {
    @file_put_contents(
        $PRIVATE_DIR . '/errors.log',
        date('d.m.Y H:i') . ' — проблема с письмом о заявке от «' . $name . '»: ' . $why
            . '. Заявка сохранена в leads.log' . "\n",
        FILE_APPEND | LOCK_EX
    );
}

/* ---------- 3. реестр для офлайн-конверсий Метрики ----------
   Готовый CSV в формате загрузки офлайн-конверсий: когда заявка
   превращается в оплату, проставляете в строке Price и грузите файл
   в Метрику. После этого Директ обучается на деньгах, а не на заявках.
   Колонки — как требует Метрика; Price оставляем пустым до сделки. */

$csvPath = $PRIVATE_DIR . '/leads-offline.csv';
if (!file_exists($csvPath)) {
    @file_put_contents($csvPath, "ClientId,yclid,Target,DateTime,Price,Currency,Comment\n", LOCK_EX);
}
@file_put_contents($csvPath, implode(',', [
    $ymUid,
    $yclid,
    'lead',
    time(),
    '',
    'RUB',
    '"' . str_replace('"', "'", $project . ' / ' . $name . ' / ' . $contact) . '"',
]) . "\n", FILE_APPEND | LOCK_EX);

// Посетителю всегда отвечаем «принято»: заявка уже сохранена в leads.log.
// Сказать ему «не отправилось» из-за проблемы на нашей стороне — значит
// потерять лид, который на самом деле у нас есть.
echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
