<?php
/* ============================================================
   Проверка приёма заявок — временный файл

   Открыть в браузере:
     https://bannikov-hr.ru/api/diag.php?key=proverka2026

   Страница по шагам проверит всю цепочку и скажет, где обрыв.
   Кнопка внизу отправляет тестовое письмо. Пароль нигде не показывается.

   ПОСЛЕ ПРОВЕРКИ ЭТОТ ФАЙЛ УДАЛИТЬ.
   ============================================================ */

$KEY = 'proverka2026';
if (($_GET['key'] ?? '') !== $KEY) {
    http_response_code(404);
    exit('Not found');
}

header('Content-Type: text/html; charset=utf-8');
header('X-Robots-Tag: noindex, nofollow');
date_default_timezone_set('Europe/Moscow');

require __DIR__ . '/mailer.php';

$rows = [];
function step($name, $ok, $detail, $fix = '') {
    global $rows;
    $rows[] = ['name' => $name, 'ok' => $ok, 'detail' => $detail, 'fix' => $fix];
}

/* ---------- 1. PHP ---------- */
step('PHP работает', true, 'Версия ' . PHP_VERSION);

/* ---------- 2. Файл настроек ---------- */
$CONFIG = null;
$where = '';
foreach ([
    __DIR__ . '/../../bannikov-config.php' => 'выше папки сайта (правильно)',
    __DIR__ . '/../bannikov-config.php'    => 'внутри папки сайта (работает, но менее безопасно)',
] as $path => $label) {
    if (is_readable($path)) { $CONFIG = @require $path; $where = $label; break; }
}
step(
    'Файл bannikov-config.php найден',
    is_array($CONFIG),
    is_array($CONFIG) ? 'Лежит ' . $where . '.' : 'Файла нет или он не читается.',
    'Скопируйте bannikov-config.sample.php, назовите bannikov-config.php и положите рядом с папкой public_html.'
);
if (!is_array($CONFIG)) $CONFIG = [];

/* ---------- 3. Адреса ---------- */
$to = trim((string) ($CONFIG['mail_to'] ?? $CONFIG['email'] ?? ''));
$toOk = (bool) filter_var($to, FILTER_VALIDATE_EMAIL);
step('Адрес для заявок (mail_to) вписан', $toOk,
    $toOk ? 'Заявки идут на ' . htmlspecialchars($to) : 'Адреса нет или в нём ошибка.',
    'Впишите в bannikov-config.php строку mail_to — ваш адрес на Яндексе.');

step('Хостинг умеет отправлять почту', function_exists('mail'),
    function_exists('mail') ? 'Письма уходят обычной почтой хостинга от robot@bannikov-hr.ru — как на старом сайте.' : 'Функция mail() на хостинге отключена.',
    'Напишите в поддержку хостинга: «включите, пожалуйста, отправку почты из PHP (функцию mail)».');

/* ---------- 4. Необязательный SMTP — только если его включили ---------- */
$user = trim((string) ($CONFIG['smtp_user'] ?? ''));
$hasPass = (string) ($CONFIG['smtp_pass'] ?? '') !== '' && ($CONFIG['smtp_pass'] ?? '') !== 'ВПИСАТЬ';
$why = '';
$authOk = false;
if (filter_var($user, FILTER_VALIDATE_EMAIL) && $hasPass) {
    $authOk = bh_smtp($CONFIG, $to, '', '', '', $why, true);
    step('Вход в Яндекс Почту удался', $authOk,
        $authOk ? 'Сайт может отправлять письма от имени ' . htmlspecialchars($user) . '.' : htmlspecialchars($why),
        'Проверьте, что вписан именно ПАРОЛЬ ПРИЛОЖЕНИЯ, а в настройках почты включено «Почтовые программы → IMAP» и «Пароли приложений и OAuth-токены».');
}

/* ---------- 5. Папка для журналов ---------- */
$dir = $CONFIG['private_dir'] ?? dirname(__DIR__, 2);
$canWrite = is_dir($dir) && is_writable($dir);
step('Журнал заявок (leads.log) можно записать', $canWrite,
    $canWrite ? 'Папка: ' . htmlspecialchars($dir) : 'Нет прав на запись: ' . htmlspecialchars($dir),
    'Попросите поддержку хостинга дать PHP права на запись в эту папку.');

/* ---------- 6. Тестовое письмо (по кнопке) ---------- */
$testMsg = '';
if (isset($_GET['test']) && $toOk) {
    $w = '';
    $ok = bh_mail($CONFIG, $to, 'Проверка сайта bannikov-hr.ru', "Это тестовое письмо со страницы проверки.\nЕсли вы его видите — заявки с сайта будут приходить сюда.\n\nВремя: " . date('d.m.Y H:i') . ' (МСК)', '', $w);
    $testMsg = $ok
        ? '✅ Тестовое письмо отправлено на ' . htmlspecialchars($to) . '. Проверьте входящие (и на всякий случай «Спам»).'
        : '⚠️ ' . htmlspecialchars($w);
}

/* ---------- 7. Последние проблемы ---------- */
$errLog = $dir . '/errors.log';
$tail = is_readable($errLog) ? array_slice(file($errLog, FILE_IGNORE_NEW_LINES), -5) : [];

$allOk = true;
foreach ($rows as $r) if (!$r['ok']) $allOk = false;
?><!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Проверка приёма заявок</title>
<style>
body{font:16px/1.6 system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;background:#F5F6F2;color:#1A1D21;margin:0;padding:40px 20px}
.w{max-width:760px;margin:0 auto}
h1{font-size:28px;margin:0 0 8px}
.sum{padding:16px 20px;border-radius:8px;margin:20px 0 28px;font-weight:600}
.sum.ok{background:#E2EFE4;color:#2F6B3F}
.sum.no{background:#F7E4DE;color:#C22C0C}
.row{background:#fff;border:1px solid #D9DCD3;border-radius:8px;padding:16px 20px;margin-bottom:10px}
.row.bad{border-color:#C22C0C}
.n{font-weight:600;display:flex;gap:10px;align-items:baseline}
.d{color:#5B6169;font-size:14.5px;margin-top:6px;word-break:break-all}
.f{background:#F7E4DE;color:#8A2408;font-size:14px;padding:10px 14px;border-radius:6px;margin-top:10px}
.btn{display:inline-block;background:#C22C0C;color:#fff;text-decoration:none;font-weight:600;padding:12px 20px;border-radius:6px;margin-top:8px}
.tail{margin-top:28px;font-size:14.5px;color:#5B6169}
pre{background:#fff;border:1px solid #D9DCD3;border-radius:6px;padding:12px;font-size:13px;white-space:pre-wrap}
</style>
</head>
<body>
<div class="w">
<h1>Проверка приёма заявок</h1>
<div class="sum <?= $allOk ? 'ok' : 'no' ?>">
<?= $allOk ? 'Всё в порядке. Нажмите кнопку внизу — придёт тестовое письмо.' : 'Есть незакрытые пункты — они отмечены ниже.' ?>
</div>

<?php if ($testMsg): ?><div class="sum <?= strpos($testMsg, '✅') === 0 ? 'ok' : 'no' ?>"><?= $testMsg ?></div><?php endif; ?>

<?php foreach ($rows as $r): ?>
  <div class="row<?= $r['ok'] ? '' : ' bad' ?>">
    <div class="n"><span><?= $r['ok'] ? '✅' : '⚠️' ?></span><span><?= htmlspecialchars($r['name']) ?></span></div>
    <div class="d"><?= $r['detail'] ?></div>
    <?php if (!$r['ok'] && $r['fix']): ?><div class="f"><?= htmlspecialchars($r['fix']) ?></div><?php endif; ?>
  </div>
<?php endforeach; ?>

<?php if ($toOk): ?><a class="btn" href="?key=<?= $KEY ?>&amp;test=1">Отправить тестовое письмо</a><?php endif; ?>

<?php if ($tail): ?>
<p class="tail"><b>Последние записи в errors.log:</b></p>
<pre><?= htmlspecialchars(implode("\n", $tail)) ?></pre>
<?php endif; ?>

<p class="tail">Когда тестовое письмо пришло — удалите с хостинга файл <code>api/diag.php</code>. Он защищён ключом, но лишних дверей на боевом сайте быть не должно.</p>
</div>
</body>
</html>
