/* ============================================================
   Калькулятор стоимости текучести — общий расчёт

   Модель согласована 4 сентября 2026 и описана в файле
   МОДЕЛЬ-РАСЧЁТА.html (лежит рядом с папкой сайта, на хост не идёт).

   Коротко, откуда берутся числа:

   1. Считаем не от оклада, а от ПОЛНОЙ месячной стоимости сотрудника:
      оклад × 1.45 (страховые взносы ~30% + рабочее место, техника,
      ПО, обучение ~12%). Прежняя версия брала 2.52 — завышение почти
      вдвое, которое дальше умножалось на всё остальное.

   2. Цена ухода = полная стоимость × (подбор + ввод + разгон).
      Коэффициенты зависят от категории должности: линейного
      заменить дешевле, руководителя — дороже и дольше.

   3. Простой рабочего места считаем по РАБОЧИМ дням (не календарным)
      и берём 30% потерь, а не 60%: часть работы подхватывают коллеги.
      База — большая из двух: стоимость переложенной работы или
      упущенная маржа. Пустое место стоит денег всегда, даже если
      должность не приносит выручку напрямую.

   4. Замещается 85% ушедших — остальные позиции закрывают
      внутренним переводом или не закрывают вовсе.

   5. Возвращается за первый год 40% сверхнормативных потерь,
      а не все 100%. Обещать полное снятие текучести за год нечестно.

   Ввод двойной: ползунок для прикидки и поле для точной цифры.
   Значения хранятся в объекте val, а не читаются из DOM, — иначе
   набранное вручную число прилипало бы к шагу ползунка.
   ============================================================ */

(function () {
  'use strict';

  var root = document.getElementById('tcalc');
  if (!root) return;

  var $ = function (id) {
    return document.getElementById(id);
  };

  var RM = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var nf = new Intl.NumberFormat('ru-RU');
  var rub = function (n) {
    return nf.format(Math.round(n)) + ' ₽';
  };

  /* ---------------- коэффициенты модели ---------------- */

  var FULL_MULT = 1.45; // оклад → полная месячная стоимость сотрудника
  var IDLE_SHARE = 0.3; // какая доля маржи действительно теряется за время простоя
  var WORK_DAYS = 250; // рабочих дней в году
  var REPLACED = 0.85; // доля позиций, которые реально замещают внешним наймом
  var RECOVER = 0.4; // сколько сверхнормативных потерь снимается за первый год

  // подбор / ввод в должность / разгон — в долях полной месячной стоимости
  var CATS = {
    line: { hire: 0.25, onb: 0.2, ramp: 0.6 },
    spec: { hire: 0.4, onb: 0.3, ramp: 1.1 },
    boss: { hire: 0.8, onb: 0.5, ramp: 1.8 }
  };

  /* ---------------- элементы ---------------- */

  /* У каждого числового поля два способа ввода: ползунок и поле для набора.
     Ползунком удобно прикидывать, полем — вписать точную цифру: шаг
     ползунка крупный, и попасть им, например, в 137 человек невозможно.

     Единственный источник правды — объект val. Ползунок и поле только
     пишут в него и читают из него, а расчёт вообще не заглядывает в DOM.
     Иначе набранное вручную число «прилипало» бы к шагу ползунка:
     вписали 73 500 ₽, а посчиталось бы 73 000. */

  var NUM = {
    staff:  { min: 5,     max: 1500,    def: 120 },
    left:   { min: 0,     max: 240,     def: 45 },
    salary: { min: 25000, max: 400000,  def: 70000 },
    days:   { min: 0,     max: 120,     def: 30 },
    margin: { min: 0,     max: 1000000, def: 0 }
  };

  var el = {
    cat: $('tc-cat'), ind: $('tc-ind'),

    vStaff: $('tc-v-staff'), vLeft: $('tc-v-left'), vSalary: $('tc-v-salary'),
    vDays: $('tc-v-days'), vMargin: $('tc-v-margin'),

    rate: $('tc-rate'), flag: $('tc-flag'), norm: $('tc-norm'),
    year: $('tc-year'), sub: $('tc-sub'),
    bHire: $('tc-b-hire'), bOnb: $('tc-b-onb'), bRamp: $('tc-b-ramp'),
    bIdle: $('tc-b-idle'), bIdleRow: $('tc-b-idle-row'), bOne: $('tc-b-one'),
    over: $('tc-over'), overSum: $('tc-over-sum'), overTxt: $('tc-over-txt')
  };

  var range = {};
  var field = {};
  var val = {};
  for (var k in NUM) {
    if (!Object.prototype.hasOwnProperty.call(NUM, k)) continue;
    range[k] = $('tc-' + k);
    field[k] = $('tc-n-' + k);
    val[k] = NUM[k].def;
  }

  // Без любого из этих узлов расчёт бессмысленен. Молча считать в никуда
  // хуже, чем не запуститься: на странице останется честный ноль.
  for (var key in el) {
    if (Object.prototype.hasOwnProperty.call(el, key) && !el[key]) return;
  }
  for (var rk in range) {
    if (Object.prototype.hasOwnProperty.call(range, rk) && (!range[rk] || !field[rk])) return;
  }

  function clamp(n, k) {
    if (!isFinite(n)) return NUM[k].def;
    return Math.min(NUM[k].max, Math.max(NUM[k].min, Math.round(n)));
  }

  /* Человек может вписать «70 000», «70000 ₽» или «70 000р» — принимаем всё:
     выкидываем пробелы и любые нецифры и берём то, что осталось. */
  function parseTyped(text) {
    var digits = String(text).replace(/[^\d]/g, '');
    return digits === '' ? NaN : parseInt(digits, 10);
  }

  /* ---------------- склонения ---------------- */

  function plural(n, one, few, many) {
    var a = n % 10;
    var b = n % 100;
    if (a === 1 && b !== 11) return one;
    if (a >= 2 && a <= 4 && (b < 10 || b >= 20)) return few;
    return many;
  }

  /* ---------------- плавный счётчик главной цифры ---------------- */

  var tweenId = null;
  var settleId = null;
  var shownYear = 0;

  function tweenYear(to) {
    if (RM) {
      el.year.textContent = rub(to);
      shownYear = to;
      return;
    }
    cancelAnimationFrame(tweenId);
    var from = shownYear;
    var t0 = performance.now();
    var dur = 420;
    (function step(t) {
      var p = Math.min(1, (t - t0) / dur);
      var e = 1 - Math.pow(1 - p, 3);
      shownYear = from + (to - from) * e;
      el.year.textContent = rub(shownYear);
      if (p < 1) tweenId = requestAnimationFrame(step);
    })(t0);
    // Главная цифра обязана дойти до конечного значения, даже если кадры
    // анимации не проигрались — например, во вкладке в фоне.
    clearTimeout(settleId);
    settleId = window.setTimeout(function () {
      shownYear = to;
      el.year.textContent = rub(to);
    }, dur + 300);
  }

  /* ---------------- расчёт ---------------- */

  var last = null;

  function calc() {
    var staff = val.staff;
    var salary = val.salary;
    var days = val.days;
    var margin = val.margin;

    // Текучесть выше 150 % за год встречается разве что в сезонном общепите,
    // и то как исключение. Выше этого расчёт превращается в фантазию,
    // поэтому потолок едет за численностью — и для ползунка, и для поля.
    var cap = Math.max(5, Math.round(staff * 1.5));
    NUM.left.max = cap;
    if (+range.left.max !== cap) range.left.max = cap;
    if (val.left > cap) val.left = cap;
    var left = val.left;

    var k = CATS[el.cat.value] || CATS.spec;
    var opt = el.ind.options[el.ind.selectedIndex];
    var nMin = +opt.dataset.min;
    var nMax = +opt.dataset.max;

    var full = salary * FULL_MULT;
    var hire = full * k.hire;
    var onb = full * k.onb;
    var ramp = full * k.ramp;

    /* Ограничитель реальности. Суммарный простой не может превысить
       365 дней на каждую ставку в компании — без этой проверки калькулятор
       соглашался, что должность стояла пустой 4800 дней за год. */
    var idleDays = days;
    var totalIdle = left * days;
    var limit = 365 * staff;
    if (totalIdle > limit && totalIdle > 0) idleDays = days * (limit / totalIdle);

    /* Пустое место стоит денег ВСЕГДА, а не только там, где есть маржа.
       Работу либо не делают, либо перекладывают на коллег — и то и другое
       компания оплачивает. Поэтому считаем две базы и берём большую:

         · по стоимости позиции — работа, переложенная на других;
         · по марже — выручка, которую никто не заработал.

       Именно большую, а не сумму: это одна и та же дыра с двух сторон,
       складывать их — двойной счёт. Плюс так добавление маржи никогда
       не уменьшает результат. */
    var workDaysIdle = (idleDays * WORK_DAYS) / 365; // календарные → рабочие
    var idleByCost = ((full * 12) / WORK_DAYS) * workDaysIdle * IDLE_SHARE;
    var idleByMargin = margin > 0 ? ((margin * 12) / WORK_DAYS) * workDaysIdle * IDLE_SHARE : 0;
    var idle = Math.max(idleByCost, idleByMargin);

    var one = hire + onb + ramp + idle;
    var year = left * REPLACED * one;
    var rate = staff > 0 ? (left / staff) * 100 : 0;
    var months = full > 0 ? one / full : 0;

    /* ---------- подписи и синхронизация полей ---------- */

    syncInputs();
    el.vStaff.textContent = plural(staff, 'человек', 'человека', 'человек');
    el.vLeft.textContent = plural(left, 'человек', 'человека', 'человек');
    el.vSalary.textContent = '₽';
    el.vDays.textContent = plural(days, 'день', 'дня', 'дней');
    el.vMargin.textContent = margin > 0 ? '₽' : '₽ · не считаем';

    /* ---------- текучесть и норма ---------- */

    el.rate.textContent = rate.toFixed(1).replace('.', ',') + ' %';
    el.norm.textContent = 'Норма для отрасли «' + opt.text + '» — ' + nMin + '–' + nMax + ' %.';
    if (rate <= nMax) {
      el.flag.textContent = 'в пределах нормы';
      el.flag.className = 'tflag tflag--ok';
    } else {
      el.flag.textContent = 'выше нормы на ' + (rate - nMax).toFixed(1).replace('.', ',') + ' п.п.';
      el.flag.className = 'tflag tflag--bad';
    }

    /* ---------- разбивка ---------- */

    el.bHire.textContent = rub(hire);
    el.bOnb.textContent = rub(onb);
    el.bRamp.textContent = rub(ramp);
    el.bIdle.textContent = rub(idle);
    el.bIdleRow.className = 'tbrk__row';
    el.bOne.textContent = rub(one);

    tweenYear(year);

    el.sub.innerHTML =
      'Один ушедший обходится в <b>' +
      months.toFixed(1).replace('.', ',') +
      '</b> полной месячной стоимости сотрудника. В отчёте о прибылях этих денег не видно: ' +
      'они размазаны по недовыработке, простою и часам чужих людей.';

    /* ---------- сверхнормативная часть ---------- */

    var overPeople = Math.max(0, ((rate - nMax) / 100) * staff);
    if (overPeople >= 0.5) {
      var overCost = overPeople * REPLACED * one;
      var recover = overCost * RECOVER;
      el.over.hidden = false;
      el.overSum.textContent = rub(recover);
      el.overTxt.innerHTML =
        'Сверх нормы отрасли уходит примерно <b>' +
        Math.round(overPeople) +
        ' ' + plural(Math.round(overPeople), 'человек', 'человека', 'человек') +
        '</b> в год — это ' + rub(overCost) + ' потерь. ' +
        'За первый год системной работы снимается около 40 % превышения: ' +
        'остальное упирается в рынок труда, географию и деньги.';
    } else {
      el.over.hidden = true;
    }

    /* ---------- строка для заявки ---------- */

    last =
      'штат ' + staff + ', уволилось ' + left + ', оклад ' + rub(salary) + ', ' +
      el.cat.options[el.cat.selectedIndex].text.toLowerCase() + ', ' + opt.text +
      (margin > 0 ? ', маржа ' + rub(margin) + '/мес' : '') +
      ' → текучесть ' + rate.toFixed(1) + ' %, один уход ' + rub(one) +
      ', потери ' + rub(year) + '/год';
  }

  /* ---------------- синхронизация ползунка и поля ----------------
     Поле не трогаем, пока человек в нём печатает: иначе курсор прыгает
     и «1» на пути к «120» мгновенно превращается в «5» из-за нижней
     границы. Поэтому в фокусе поле живёт своей жизнью, а выравнивается
     по уходу фокуса. */

  function syncInputs() {
    for (var k in NUM) {
      if (!Object.prototype.hasOwnProperty.call(NUM, k)) continue;
      if (+range[k].value !== val[k]) range[k].value = val[k];
      if (document.activeElement !== field[k]) field[k].value = nf.format(val[k]);
    }
  }

  var goalSent = false;
  var resultSeen = false;
  var resultSent = false;

  // Досчитал и увидел результат — это уже не случайный заход.
  // Отдельная цель, чтобы таких людей можно было догонять в Директе.
  // Нужны оба условия: без «трогал» цель срабатывала бы при простом
  // открытии страницы — блок результата виден сразу.
  function maybeResult() {
    if (resultSent || !goalSent || !resultSeen) return;
    resultSent = true;
    Site.reachGoal('calc_result');
  }

  function touched() {
    if (goalSent) return;
    Site.reachGoal('calc_use');
    goalSent = true;
    maybeResult();
  }

  Object.keys(NUM).forEach(function (k) {
    // ползунок — прикинуть на глаз
    range[k].addEventListener('input', function () {
      val[k] = clamp(+range[k].value, k);
      calc();
      touched();
    });

    // поле — вписать точное число
    field[k].addEventListener('input', function () {
      var n = parseTyped(field[k].value);
      if (isNaN(n)) return; // поле пустое или чистится — ждём
      val[k] = clamp(n, k);
      calc();
      touched();
    });

    // ушли из поля — приводим к нормальному виду
    field[k].addEventListener('blur', function () {
      var n = parseTyped(field[k].value);
      val[k] = isNaN(n) ? val[k] : clamp(n, k);
      field[k].value = nf.format(val[k]);
      calc();
    });

    // Enter не должен отправлять форму заявки, которая ниже на странице
    field[k].addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        field[k].blur();
      }
    });
  });

  ['cat', 'ind'].forEach(function (name) {
    el[name].addEventListener('change', function () {
      calc();
      touched();
    });
  });

  calc();

  var out = root.querySelector('.tcalc__out') || root;
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (e) {
          if (e.isIntersecting) {
            resultSeen = true;
            maybeResult();
            io.disconnect();
          }
        });
      },
      // порог небольшой: на телефоне блок результата выше экрана,
      // и 40 % его площади могли бы не поместиться в окно никогда
      { threshold: 0.15 }
    );
    io.observe(out);
  } else {
    resultSeen = true;
  }

  // Расчёт человека уходит вместе с заявкой — по нему сразу видно,
  // о какой компании речь, и разбор начинается не с нуля.
  window.TurnoverCalc = {
    summary: function () {
      return last;
    }
  };
})();
