/* ============================================================
   /audit/ — поведение страницы HR-аудита
   Форма заявки, всплывающая форма, лента кейсов.
   ============================================================ */

(function () {
  'use strict';

  var $ = function (sel) {
    return document.querySelector(sel);
  };

  /* ---------- основная форма ---------- */

  Site.bindLeadForm({
    form: '#leadForm',
    project: 'audit',
    goal: 'lead_audit',
    fields: { name: '#fName', contact: '#fContact', size: '#fSize', pain: '#fPain' },
    agree: '#fAgree',
    hp: '#fHoney',
    err: '#fErr',
    button: '#fBtn',
    messages: {
      name: 'Заполните, пожалуйста, имя.',
      contact: 'Оставьте контакт — телефон, Telegram или почту.',
      agree: 'Поставьте галочку согласия на обработку данных.',
      fail: 'Не получилось отправить. Напишите напрямую в Telegram: t.me/dmitrybam'
    },
    onSuccess: function () {
      $('#leadForm').style.display = 'none';
      $('#fDone').style.display = 'block';
      hideFab();
    }
  });

  /* ---------- плавающая кнопка и всплывающая форма ---------- */

  var overlay = $('#popupOverlay');
  var fab = $('#fabBtn');

  function hideFab() {
    if (fab) fab.style.display = 'none';
  }

  function openPopup() {
    if (!overlay || Site.leadCaptured()) return;
    overlay.classList.add('show');
    document.body.style.overflow = 'hidden';
    Site.reachGoal('popup_open');
    try {
      sessionStorage.setItem('popupSeen', '1');
    } catch (e) {}
  }

  function closePopup() {
    if (!overlay) return;
    overlay.classList.remove('show');
    document.body.style.overflow = '';
  }

  function popupSeen() {
    try {
      return !!sessionStorage.getItem('popupSeen');
    } catch (e) {
      return true;
    }
  }

  if (overlay && fab) {
    if (Site.leadCaptured()) hideFab();

    fab.addEventListener('click', openPopup);
    $('#popupClose').addEventListener('click', closePopup);
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closePopup();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && overlay.classList.contains('show')) closePopup();
    });

    // через 40 секунд чтения — один раз за сессию
    window.setTimeout(function () {
      if (!popupSeen() && !Site.leadCaptured()) openPopup();
    }, 40000);

    Site.bindLeadForm({
      form: '#popupForm',
      project: 'audit',
      goal: 'lead_audit',
      source: 'Всплывающая форма',
      fields: { name: '#pfName', contact: '#pfContact' },
      agree: '#pfAgree',
      hp: '#pfHoney',
      err: '#pfErr',
      button: '#pfBtn',
      messages: {
        name: 'Заполните, пожалуйста, имя.',
        contact: 'Оставьте контакт — телефон, Telegram или почту.',
        agree: 'Поставьте галочку согласия на обработку данных.',
        fail: 'Не получилось отправить. Напишите напрямую в Telegram: t.me/dmitrybam'
      },
      onSuccess: function () {
        $('#popupForm').style.display = 'none';
        $('#pfDone').style.display = 'block';
        hideFab();
        window.setTimeout(closePopup, 2500);
      }
    });
  }

  /* ---------- лента кейсов ---------- */

  (function () {
    var vp = $('#casesVp');
    var track = $('#casesTrack');
    if (!vp || !track) return;

    // движение выключено — просто оставляем ленту прокручиваемой пальцем
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      vp.style.overflowX = 'auto';
      return;
    }

    // дублируем набор карточек, чтобы петля была бесшовной
    track.innerHTML += track.innerHTML;

    var setW = 0,
      offset = 0,
      speed = 0.4,
      hovering = false,
      dragging = false,
      startX = 0,
      startOffset = 0,
      moved = 0;

    function measure() {
      setW = track.scrollWidth / 2;
    }
    function norm() {
      if (setW > 0) {
        while (offset >= setW) offset -= setW;
        while (offset < 0) offset += setW;
      }
    }
    function apply() {
      track.style.transform = 'translateX(-' + offset + 'px)';
    }

    measure();
    window.addEventListener('resize', function () {
      var ratio = setW ? offset / setW : 0;
      measure();
      offset = ratio * setW;
      norm();
      apply();
    });

    // Лента крутится, только пока её видно. Вне экрана движение никому
    // не нужно, а вебвизор записывал бы каждый её кадр и раздувал запись.
    var onScreen = true;
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        onScreen = entries[0].isIntersecting;
      }).observe(vp);
    }

    (function loop() {
      if (onScreen && !hovering && !dragging) {
        offset += speed;
        norm();
        apply();
      }
      requestAnimationFrame(loop);
    })();

    vp.addEventListener('mouseenter', function () {
      hovering = true;
    });
    vp.addEventListener('mouseleave', function () {
      hovering = false;
    });
    vp.addEventListener(
      'wheel',
      function (e) {
        // Обычное колесо мыши крутит страницу, а не ленту: иначе человек,
        // листающий вниз, застревал на кейсах. Ленту двигает только
        // горизонтальный жест тачпада.
        if (Math.abs(e.deltaX) <= Math.abs(e.deltaY)) return;
        e.preventDefault();
        offset += e.deltaX;
        norm();
        apply();
      },
      { passive: false }
    );
    vp.addEventListener('pointerdown', function (e) {
      dragging = true;
      moved = 0;
      startX = e.clientX;
      startOffset = offset;
      vp.classList.add('grabbing');
      vp.setPointerCapture(e.pointerId);
    });
    vp.addEventListener('pointermove', function (e) {
      if (!dragging) return;
      var dx = e.clientX - startX;
      moved = Math.max(moved, Math.abs(dx));
      offset = startOffset - dx;
      norm();
      apply();
    });
    function endDrag(e) {
      if (!dragging) return;
      dragging = false;
      vp.classList.remove('grabbing');
      try {
        vp.releasePointerCapture(e.pointerId);
      } catch (_) {}
    }
    vp.addEventListener('pointerup', endDrag);
    vp.addEventListener('pointercancel', endDrag);
    // после перетаскивания клик по карточке не должен срабатывать
    vp.addEventListener(
      'click',
      function (e) {
        if (moved > 6) {
          e.preventDefault();
          e.stopPropagation();
        }
      },
      true
    );
  })();
})();
