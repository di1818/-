/* ============================================================
   / — поведение главной страницы.
   Прорисовка первого экрана, человечек, видео, окно записи.
   ============================================================ */

(function () {
  'use strict';

  var $ = function (s, r) {
    return (r || document).querySelector(s);
  };
  var $$ = function (s, r) {
    return Array.prototype.slice.call((r || document).querySelectorAll(s));
  };

  var RM = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var stage = $('#stage');

  /* ============================================================
     ПРОРИСОВКА ПЕРВОГО ЭКРАНА

     Прячет элементы класс .js-anim на <html> — его ставит короткий
     скрипт в <head>, он же страхует показ по таймеру. Здесь только
     раздаём словам заголовка порядковый номер и включаем отрисовку.
     ============================================================ */

  if (stage) {
    $$('.stage__h1 .w').forEach(function (w, i) {
      w.style.setProperty('--i', i);
    });
    // ждём кадр: без него браузер может схлопнуть исходное и конечное
    // состояние в одно и показать всё разом, без прорисовки
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        stage.classList.add('is-drawn');
      });
    });
  }

  /* ============================================================
     ЧЕЛОВЕЧЕК

     Глаза едут за курсором, улыбается при наведении на видео и кнопки.
     Слежка только там, где есть настоящий курсор: на телефоне
     hover-состояний нет, а лишний обработчик движения — лишний расход.
     ============================================================ */

  (function () {
    var dude = $('#dude');
    var eyes = $('#dudeEyes');
    if (!dude || !eyes) return;

    var FINE = window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches;

    /* ---------- глаза ---------- */

    if (FINE && !RM) {
      var MAX_X = 9; // в единицах viewBox человечка
      var MAX_Y = 6;
      var pending = false;
      var mx = 0;
      var my = 0;

      function move() {
        pending = false;
        var b = dude.getBoundingClientRect();
        if (!b.width) return;
        // центр «лица», а не всей картинки: голова занимает верхнюю треть
        var cx = b.left + b.width / 2;
        var cy = b.top + b.height * 0.26;
        var dx = mx - cx;
        var dy = my - cy;
        var d = Math.sqrt(dx * dx + dy * dy) || 1;
        // нормируем по расстоянию: вблизи глаза доходят до края,
        // издалека просто указывают направление
        var k = Math.min(1, d / 320);
        eyes.style.transform =
          'translate(' + ((dx / d) * MAX_X * k).toFixed(2) + 'px,' +
          ((dy / d) * MAX_Y * k).toFixed(2) + 'px)';
      }

      window.addEventListener(
        'mousemove',
        function (e) {
          mx = e.clientX;
          my = e.clientY;
          if (pending) return;
          pending = true;
          requestAnimationFrame(move);
        },
        { passive: true }
      );

      // курсор ушёл со страницы — взгляд возвращается прямо
      document.addEventListener('mouseleave', function () {
        eyes.style.transform = '';
      });

      /* ---------- моргание ---------- */

      (function blink() {
        window.setTimeout(function () {
          dude.classList.add('is-blink');
          window.setTimeout(function () {
            dude.classList.remove('is-blink');
            blink();
          }, 120);
        }, 2600 + Math.random() * 4200);
      })();
    }

    /* ---------- улыбка ---------- */

    // Наведение на видео и на любую кнопку первого экрана.
    // Держим счётчик: между двумя соседними кнопками курсор проходит
    // через промежуток, и по одному mouseleave улыбка бы мигала.
    var hot = $$('#vid, .stage__cta .btn, .stage__pick a, .site-header .nav-actions .btn');
    var over = 0;

    function happy(on) {
      over = Math.max(0, over + (on ? 1 : -1));
      dude.classList.toggle('is-happy', over > 0);
    }

    hot.forEach(function (el) {
      el.addEventListener('mouseenter', function () {
        happy(true);
      });
      el.addEventListener('mouseleave', function () {
        happy(false);
      });
      // клавиатура: фокус на кнопке — тот же отклик, что и наведение
      el.addEventListener('focus', function () {
        happy(true);
      });
      el.addEventListener('blur', function () {
        happy(false);
      });
    });
  })();

  /* ============================================================
     ВИДЕО

     Ролика ещё нет. Ссылка на встраивание задаётся один раз в
     data-embed у блока #vid — до тех пор клик по заглушке просто
     ничего не ломает. Плеер подгружается по клику, а не при заходе:
     чужой iframe тянет свои скрипты и куки и тормозит первый экран.
     ============================================================ */

  (function () {
    var vid = $('#vid');
    if (!vid) return;

    var src = (vid.getAttribute('data-embed') || '').trim();

    vid.addEventListener('click', function () {
      if (!src || vid.classList.contains('is-live')) return;

      var frame = document.createElement('iframe');
      // autoplay в конце: человек уже нажал «play», второй клик лишний
      frame.src = src + (src.indexOf('?') > -1 ? '&' : '?') + 'autoplay=1';
      frame.title = 'Видео о практикуме «HR Инструментарий»';
      frame.allow = 'autoplay; fullscreen; clipboard-write; encrypted-media; picture-in-picture';
      frame.setAttribute('allowfullscreen', '');
      frame.setAttribute('loading', 'lazy');

      vid.appendChild(frame);
      vid.classList.add('is-live');
      Site.reachGoal('video_play');
    });
  })();

  /* Окно записи на вебинар живёт в site.js: оно нужно и здесь,
     и на странице практикума. Разметка окна — в обеих страницах. */
})();
