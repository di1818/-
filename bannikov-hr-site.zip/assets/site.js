/* ============================================================
   bannikov-hr.ru — общие скрипты
   Cookie-бар, появление блоков при скролле, цели Метрики,
   отправка заявок. Специфика страниц — в отдельных файлах.
   ============================================================ */

(function () {
  'use strict';

  var FORM_ENDPOINT = '/api/send.php';
  var UTM_KEYS = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'yclid', 'gclid'];

  // Директ принимает офлайн-конверсии по yclid в течение 90 дней —
  // столько же храним метку, чтобы заявка от вернувшегося человека
  // не потеряла рекламный источник.
  var SRC_KEY = 'bh_src';
  var SRC_TTL = 90 * 24 * 60 * 60 * 1000;

  var SECTION = window.SITE_SECTION || 'hub';

  /* ============================================================
     ЦЕННОСТЬ ЗАЯВКИ ДЛЯ ДИРЕКТА

     Это НЕ цена услуги, а ожидаемая выручка с одной заявки:
     средний чек × доля заявок, которые доходят до оплаты.
     Директ использует эти числа в стратегиях «по ценности
     конверсии» и в ДРР. Завышать нельзя — стратегия начнёт
     переплачивать за клик и сольёт бюджет.

     Ниже — стартовая прикидка от текущих цен (практикум от 60 000 ₽)
     при консервативных 25% доходимости.
     Как накопится статистика по сделкам — поставьте свои цифры.
     ============================================================ */
  var LEAD_VALUE = {
    audit: 5000,
    praktikum: 15000,
    // Запись на бесплатный вебинар — верх воронки: до практикума доходит
    // заметно меньшая доля, чем с прямой заявки. Цифра стартовая,
    // поменяйте, когда наберётся статистика «вебинар → оплата».
    webinar: 8000,
    hub: 7000,
    calculator: 4000
  };

  /* ---------- цели Яндекс.Метрики ---------- */

  function reachGoal(name, params) {
    var ids = window.METRIKA_IDS || [];
    if (!ids.length) return;

    // section в каждой цели — чтобы в Метрике можно было
    // разложить любую цель по разделам, не заводя отдельных целей
    var p = { section: SECTION };
    if (params) {
      for (var k in params) {
        if (Object.prototype.hasOwnProperty.call(params, k)) p[k] = params[k];
      }
    }

    for (var i = 0; i < ids.length; i++) {
      try {
        window.ym(ids[i], 'reachGoal', name, p);
      } catch (e) {
        /* счётчик ещё не загрузился — цель просто теряется, ломать страницу не за что */
      }
    }
  }

  /* ---------- источник трафика ---------- */

  function captureSource() {
    try {
      var q = new URLSearchParams(location.search);
      var found = {};
      var has = false;
      UTM_KEYS.forEach(function (k) {
        var v = q.get(k);
        if (v) {
          found[k] = v.slice(0, 200);
          has = true;
        }
      });
      if (!has) return;
      // last click: свежий переход по рекламе перекрывает старый —
      // именно по нему Директ считает конверсию
      found._ts = Date.now();
      localStorage.setItem(SRC_KEY, JSON.stringify(found));
    } catch (e) {}
  }

  function savedSource() {
    try {
      var raw = localStorage.getItem(SRC_KEY);
      if (!raw) return null;
      var o = JSON.parse(raw);
      if (!o || !o._ts || Date.now() - o._ts > SRC_TTL) {
        localStorage.removeItem(SRC_KEY);
        return null;
      }
      return o;
    } catch (e) {
      return null;
    }
  }

  function sourceString() {
    var parts = [];
    var o = savedSource();
    if (o) {
      UTM_KEYS.forEach(function (k) {
        if (o[k]) parts.push(k.replace('utm_', '') + '=' + o[k]);
      });
    }
    if (!parts.length && document.referrer) {
      try {
        var host = new URL(document.referrer).hostname;
        if (host && host !== location.hostname) parts.push('ref=' + host);
      } catch (e) {}
    }
    return parts.join(' · ') || 'прямой заход';
  }

  // ClientID Метрики. Берём из куки, а не через ym('getClientID'),
  // чтобы не задерживать отправку заявки ожиданием счётчика.
  // Нужен, чтобы потом загрузить в Метрику офлайн-конверсию
  // «заявка → оплаченная сделка».
  function ymClientId() {
    var m = document.cookie.match(/(?:^|;\s*)_ym_uid=([^;]+)/);
    return m ? decodeURIComponent(m[1]) : '';
  }

  /* ---------- отправка заявки ---------- */

  function submitLead(data) {
    var payload = {};
    for (var k in data) if (Object.prototype.hasOwnProperty.call(data, k)) payload[k] = data[k];

    var src = savedSource() || {};
    payload.source = payload.source || sourceString();
    payload.page = location.pathname;
    payload.section = SECTION;
    payload.yclid = src.yclid || '';
    payload.utm_source = src.utm_source || '';
    payload.utm_medium = src.utm_medium || '';
    payload.utm_campaign = src.utm_campaign || '';
    payload.utm_content = src.utm_content || '';
    payload.utm_term = src.utm_term || '';
    payload.ym_uid = ymClientId();

    return fetch(FORM_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(function (r) {
        return r.json();
      })
      .then(function (r) {
        if (!r || !r.ok) throw new Error(r && r.error ? r.error : 'send failed');
        return r;
      });
  }

  /* ---------- привязка формы заявки ---------- */

  var DEFAULT_MESSAGES = {
    name: 'Напишите, как к вам обращаться',
    contact: 'Оставьте контакт — иначе я не смогу ответить',
    agree: 'Без согласия на обработку данных не могу принять заявку',
    fail: 'Не отправилось. Напишите напрямую в Telegram: t.me/dmitrybam'
  };

  function bindLeadForm(opts) {
    var $ = function (sel) {
      return typeof sel === 'string' ? document.querySelector(sel) : sel;
    };
    var form = $(opts.form);
    if (!form) return;

    var errBox = $(opts.err);
    var button = $(opts.button);
    var msg = Object.assign({}, DEFAULT_MESSAGES, opts.messages || {});
    var idleLabel = button ? button.textContent : '';
    var project = opts.project || SECTION;

    // «форму увидели» — честный знаменатель конверсии формы.
    // Без него непонятно, что чинить: подводку к форме или саму форму.
    if ('IntersectionObserver' in window) {
      var seen = false;
      var vio = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (e) {
            if (e.isIntersecting && !seen) {
              seen = true;
              reachGoal('form_view');
              vio.disconnect();
            }
          });
        },
        { threshold: 0.3 }
      );
      vio.observe(form);
    }

    // «начал заполнять» — показывает, сколько людей дошло до формы,
    // но не отправило
    var started = false;
    form.addEventListener(
      'input',
      function () {
        if (started) return;
        started = true;
        reachGoal('form_start');
      },
      true
    );

    function showError(text) {
      if (errBox) errBox.textContent = text;
      // молча упавшая валидация — самая незаметная дыра в конверсии:
      // человек жмёт «отправить», ничего не происходит, он уходит
      if (text) reachGoal('form_error', { reason: text.slice(0, 60) });
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();

      var payload = { project: project };
      var fields = opts.fields || {};
      for (var key in fields) {
        if (!Object.prototype.hasOwnProperty.call(fields, key)) continue;
        var el = $(fields[key]);
        payload[key] = el ? String(el.value || '').trim() : '';
      }

      if (!payload.name) return showError(msg.name);
      if (!payload.contact) return showError(msg.contact);

      var agreeEl = $(opts.agree);
      if (agreeEl && !agreeEl.checked) return showError(msg.agree);
      payload.agree = true;

      var hpEl = $(opts.hp);
      payload.hp = hpEl ? hpEl.value : '';

      if (opts.source) payload.source = opts.source;
      // страница может дополнить заявку своими полями
      if (opts.extra) opts.extra(payload);

      showError('');
      if (button) {
        button.disabled = true;
        button.textContent = opts.sending || 'Отправляю…';
      }

      submitLead(payload)
        .then(function () {
          var value = { order_price: LEAD_VALUE[project] || LEAD_VALUE.hub, currency: 'RUB' };
          // цель по разделу — для аналитики и отдельных кампаний Директа
          if (opts.goal) reachGoal(opts.goal, value);
          // сквозная цель — её и ставим ключевой в Директе: у одного раздела
          // редко набирается 10 конверсий в неделю, а стратегиям без этого
          // не на чем обучаться
          reachGoal('lead', value);
          try {
            sessionStorage.setItem('leadCaptured', '1');
          } catch (e2) {}
          if (opts.onSuccess) opts.onSuccess();
        })
        .catch(function () {
          if (button) {
            button.disabled = false;
            button.textContent = idleLabel;
          }
          if (errBox) errBox.textContent = msg.fail;
          reachGoal('form_fail');
        });
    });
  }

  function leadCaptured() {
    try {
      return !!sessionStorage.getItem('leadCaptured');
    } catch (e) {
      return false;
    }
  }

  /* ---------- cookie-бар ---------- */

  function initCookie() {
    var bar = document.getElementById('cookieBar');
    var ok = document.getElementById('cookieOk');
    if (!bar || !ok) return;
    if (!(window.METRIKA_IDS || []).length) return; // без счётчика уведомление не нужно

    var seen;
    try {
      seen = localStorage.getItem('cookie-ok');
    } catch (e) {
      seen = '1';
    }
    if (seen) return;

    bar.classList.add('on');
    document.body.classList.add('has-cookie');
    ok.addEventListener('click', function () {
      try {
        localStorage.setItem('cookie-ok', '1');
      } catch (e) {}
      bar.classList.remove('on');
      document.body.classList.remove('has-cookie');
    });
  }

  /* ---------- появление блоков ---------- */

  function initReveal() {
    var items = document.querySelectorAll('.rv');
    if (!items.length) return;

    function revealAll() {
      for (var i = 0; i < items.length; i++) items[i].classList.add('on');
    }

    var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced || !('IntersectionObserver' in window)) {
      revealAll();
      return;
    }

    var observerWorks = false;
    var io = new IntersectionObserver(
      function (entries) {
        observerWorks = true;
        entries.forEach(function (e) {
          if (e.isIntersecting) {
            e.target.classList.add('on');
            io.unobserve(e.target);
          }
        });
      },
      { rootMargin: '0px 0px -8% 0px', threshold: 0.05 }
    );
    for (var j = 0; j < items.length; j++) io.observe(items[j]);

    // Страховка. Блоки скрыты через opacity:0, и если наблюдатель почему-то
    // не отработал (фоновая вкладка, нестандартный браузер, ошибка движка),
    // половина страницы осталась бы пустой. Анимация — приятное дополнение,
    // видимость текста — обязательна.
    window.setTimeout(function () {
      if (!observerWorks) {
        io.disconnect();
        revealAll();
      }
    }, 1500);
  }

  /* ---------- клики по контактам и кнопкам ---------- */

  // Подпись кнопки для отчёта: текст, а у кнопок-иконок — aria-label
  function buttonLabel(el) {
    var t = (el.getAttribute('aria-label') || el.textContent || '').replace(/\s+/g, ' ').trim();
    return t.slice(0, 60) || el.tagName.toLowerCase();
  }

  function initGoals() {
    document.addEventListener('click', function (e) {
      if (!e.target.closest) return;

      // ЛЮБОЙ клик по кнопке или ссылке — одна цель click_button,
      // а какая именно кнопка — в параметрах (раздел «Параметры визитов»).
      // Так метрика есть у каждой кнопки, в том числе у тех, что появятся
      // при следующих правках, и их не нужно размечать руками.
      var btn = e.target.closest('a[href], button, summary, input[type="submit"], [role="button"]');
      if (btn) {
        reachGoal('click_button', {
          button: buttonLabel(btn),
          target: (btn.getAttribute('href') || btn.id || '').slice(0, 120)
        });
      }

      // явно размеченные элементы
      var tagged = e.target.closest('[data-goal]');
      if (tagged) reachGoal(tagged.getAttribute('data-goal'));

      // остальное распознаём по самой ссылке, чтобы не размечать руками
      // каждую кнопку и не забыть про неё при следующей правке
      var a = e.target.closest('a[href]');
      if (!a) return;
      var href = a.getAttribute('href') || '';
      var path = href.split('#')[0];
      var hash = href.indexOf('#') > -1 ? href.slice(href.indexOf('#')) : '';

      if (!tagged) {
        if (/^tel:/i.test(href)) reachGoal('click_phone');
        else if (/^mailto:/i.test(href)) reachGoal('click_email');
        else if (/^https?:\/\/t\.me\//i.test(href)) reachGoal('click_tg');
      }
      if (/^\/calculator\/?$/.test(path)) reachGoal('click_calculator');
      if (/^\/praktikum\/?$/.test(path)) reachGoal('click_praktikum');
      if (/^\/audit\/?$/.test(path)) reachGoal('click_audit');
      if (/^\/blog\//.test(path)) reachGoal('click_blog');
      // клик по любой кнопке, ведущей к форме — верх воронки заявки
      if (/^#(contact|form|reg|tracks|join|joinForm)$/.test(hash)) reachGoal('cta_form');
    });
  }

  /* ---------- глубина просмотра и время на странице ---------- */

  // Обе цели — вспомогательные. Ключевой в Директе их ставить нельзя
  // (оптимизировать рекламу на «долистал» бессмысленно), но они дают
  // сегменты для ретаргетинга: «читал, но не оставил заявку».
  function initEngagement() {
    var marks = [50, 75];
    var hit = {};
    var timer = null;

    function measure() {
      timer = null;
      var doc = document.documentElement;
      var full = Math.max(doc.scrollHeight, document.body.scrollHeight) - window.innerHeight;
      // Короткая страница целиком помещается в экран — считаем её досмотренной.
      // Порог намеренно большой: сразу после DOMContentLoaded картинки и шрифты
      // ещё не разложены, высота занижена, и без него обе цели срабатывали
      // бы на каждой загрузке, до единого движения пальцем.
      var p = full > 300 ? ((window.pageYOffset || doc.scrollTop) / full) * 100 : 100;
      for (var i = 0; i < marks.length; i++) {
        if (p >= marks[i] && !hit[marks[i]]) {
          hit[marks[i]] = true;
          reachGoal('scroll_' + marks[i]);
        }
      }
      if (hit[75]) window.removeEventListener('scroll', onScroll);
    }

    // Троттлинг на таймере, а не на requestAnimationFrame: в фоновой вкладке
    // кадры не выдаются, флаг «замер запланирован» так и остался бы поднятым,
    // и после возврата на вкладку скролл больше не считался бы вообще.
    function onScroll() {
      if (timer) return;
      timer = window.setTimeout(measure, 200);
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    // первый замер — только когда вёрстка окончательно разложилась
    if (document.readyState === 'complete') window.setTimeout(measure, 0);
    else window.addEventListener('load', function () { window.setTimeout(measure, 0); });

    // минута на странице: отсекает случайные заходы и ботов,
    // из этого получается сегмент «реально читал»
    window.setTimeout(function () {
      reachGoal('time_60');
    }, 60000);
  }

  /* ============================================================
     ОКНО ЗАПИСИ НА ВЕБИНАР

     Две ветки: личный Telegram (человек пишет «вебинар», запись
     вручную) и телефон. Телефонная ветка не
     ограничивается номером: кто не звонит — оставляет контакт,
     и заявка всё равно фиксируется.

     Разметка окна лежит в HTML страницы. Здесь только поведение,
     поэтому один и тот же код обслуживает и главную, и практикум.
     ============================================================ */

  function initWebinarModal() {
    var $ = function (s, r) { return (r || document).querySelector(s); };
    var $$ = function (s, r) {
      return Array.prototype.slice.call((r || document).querySelectorAll(s));
    };

    var modal = $('#webModal');
    if (!modal) return;

    var box = $('.modal__box', modal);
    var phoneBtn = $('#webPhoneBtn');
    var phoneWrap = $('#webPhone');
    var hint = $('#webHint');
    var opener = null;

    function focusables() {
      return $$('a[href],button:not([disabled]),input,select,textarea', box).filter(function (el) {
        return el.offsetParent !== null;
      });
    }

    function open(from) {
      opener = from || null;
      modal.hidden = false;
      document.body.style.overflow = 'hidden';
      var f = focusables();
      if (f.length) f[0].focus();
      reachGoal('webinar_open');
    }

    function close() {
      modal.hidden = true;
      document.body.style.overflow = '';
      // возвращаем фокус туда, откуда окно открыли, — иначе человек
      // с клавиатуры оказывается в начале страницы
      if (opener && opener.focus) opener.focus();
      opener = null;
    }

    $$('[data-webinar]').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        open(btn);
      });
    });

    $$('[data-close]', modal).forEach(function (el) {
      el.addEventListener('click', close);
    });

    document.addEventListener('keydown', function (e) {
      if (modal.hidden) return;
      if (e.key === 'Escape') { close(); return; }
      if (e.key !== 'Tab') return;
      // фокус не должен уходить под окно, пока оно открыто
      var f = focusables();
      if (!f.length) return;
      var first = f[0];
      var last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    });

    if (phoneBtn && phoneWrap) {
      phoneBtn.addEventListener('click', function () {
        phoneWrap.hidden = false;
        phoneBtn.setAttribute('aria-expanded', 'true');
        if (hint) hint.hidden = true;
        var name = $('#wName');
        if (name) name.focus();
        reachGoal('webinar_phone');
      });
      phoneBtn.setAttribute('aria-expanded', 'false');
      phoneBtn.setAttribute('aria-controls', 'webPhone');
    }

    bindLeadForm({
      form: '#webForm',
      project: 'webinar',
      goal: 'lead_webinar',
      fields: { name: '#wName', contact: '#wContact' },
      agree: '#wAgree',
      hp: '#wHoney',
      err: '#wErr',
      button: '#wBtn',
      messages: {
        name: 'Напишите, как к вам обращаться.',
        contact: 'Оставьте телефон или Telegram — иначе я не смогу перезвонить.',
        agree: 'Без согласия на обработку данных не могу принять заявку.',
        fail: 'Не отправилось. Напишите напрямую в Telegram: t.me/dmitrybam'
      },
      extra: function (payload) {
        payload.comment = 'Запись на бесплатный вебинар, просит перезвонить';
      },
      onSuccess: function () {
        $('#webForm').style.display = 'none';
        var tel = $('.modal__tel');
        if (tel) tel.style.display = 'none';
        $$('.modal__hint', phoneWrap).forEach(function (el) { el.style.display = 'none'; });
        $('#webDone').classList.add('on');
      }
    });
  }

  /* ---------- запуск ---------- */

  captureSource();

  function start() {
    initCookie();
    initReveal();
    initWebinarModal();
    initGoals();
    initEngagement();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }

  window.Site = {
    reachGoal: reachGoal,
    submitLead: submitLead,
    sourceString: sourceString,
    bindLeadForm: bindLeadForm,
    leadCaptured: leadCaptured,
    section: SECTION
  };
})();
