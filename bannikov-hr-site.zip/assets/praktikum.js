/* ============================================================
   /praktikum/ — форма записи на бесплатную консультацию.

   Окно записи на вебинар обслуживает site.js: оно общее
   с главной страницей.
   ============================================================ */

(function () {
  'use strict';

  Site.bindLeadForm({
    form: '#joinForm',
    project: 'praktikum',
    goal: 'lead_praktikum',
    fields: { name: '#jName', contact: '#jContact', size: '#jSize' },
    agree: '#jAgree',
    hp: '#jHoney',
    err: '#jErr',
    button: '#jBtn',
    messages: {
      name: 'Напишите, как к вам обращаться.',
      contact: 'Оставьте контакт — иначе я не смогу с вами связаться.',
      agree: 'Без согласия на обработку данных не могу принять заявку.',
      fail: 'Не отправилось. Напишите напрямую в Telegram: t.me/dmitrybam'
    },
    extra: function (payload) {
      payload.comment = 'Запись на бесплатную консультацию со страницы практикума';
    },
    onSuccess: function () {
      document.getElementById('joinForm').style.display = 'none';
      var or = document.querySelector('.prg-form__or');
      if (or) or.style.display = 'none';
      document.getElementById('joinDone').classList.add('on');
    }
  });
})();
