/* ============================================================
   /calculator/ — обвязка страницы

   Сам расчёт живёт в assets/calc.js: тот же блок стоит
   на /praktikum/, и обе страницы считают по одной модели.
   Здесь остаётся только форма заявки под расчётом.
   ============================================================ */

(function () {
  'use strict';

  Site.bindLeadForm({
    form: '#calcLeadForm',
    project: 'calculator',
    goal: 'lead_calculator',
    fields: { name: '#clName', contact: '#clContact' },
    agree: '#clAgree',
    hp: '#clHoney',
    err: '#clErr',
    button: '#clBtn',
    messages: {
      name: 'Заполните, пожалуйста, имя.',
      contact: 'Оставьте контакт — телефон, Telegram или почту.',
      agree: 'Поставьте галочку согласия на обработку данных.',
      fail: 'Не получилось отправить. Напишите напрямую в Telegram: t.me/dmitrybam'
    },
    extra: function (payload) {
      // Расчёт человека уходит вместе с заявкой — по нему сразу видно,
      // о какой компании речь, и разбор начинается не с нуля.
      var calc = window.TurnoverCalc;
      if (calc && calc.summary()) payload.comment = calc.summary();
    },
    onSuccess: function () {
      document.getElementById('calcLeadForm').style.display = 'none';
      document.getElementById('clDone').classList.add('on');
    }
  });
})();
